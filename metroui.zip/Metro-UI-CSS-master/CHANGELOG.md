## Version 2.0.7

### Changes:
- fix color error in treeview
- add minfied js in one file: metro.min.js

## Version 2.0.6

### Changes:
- upd treeview, add events for collapse and expand node

## Version 2.0.5

### Changes:
- init scroll bar component (prototype)
- upd treeview
- fix bugs

## Version 2.0.4

### Changes:
- change dropdown menu default style
- add dropdown menu inverse style
- fix any bugs

## Version 2.0.3

### Changes:
- fix any bugs

## Version 2.0.2

### Changes:
- fixed minor bugs
- new component streamer (prototype)

## Version 2.0.1

### Changes:
- change buttons.less > button:active for remove dead zone tearly text in button
- added new method value to slider

### Limitation:
- no responsive module (only prototype)
- no tiles drag feature